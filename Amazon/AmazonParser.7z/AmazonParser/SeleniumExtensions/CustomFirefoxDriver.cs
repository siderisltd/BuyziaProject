﻿namespace AmazonParser.SeleniumExtensions
{
    using System;
    using Models;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Firefox;
    using OpenQA.Selenium.Support.UI;

    public class CustomFirefoxDriver : FirefoxDriver, ICustomWebDriver
    {
        public CustomFirefoxDriver(FirefoxProfile profile)
            : base(profile)
        {
        }

        public ItemDetailsObject ParseAmazonProduct(string url, WebDriverWait wait)
        {
            var driver = this;
            var currentItem = new ItemDetailsObject();


            driver.Navigate().GoToUrl(url);
            String winHandleBefore = driver.CurrentWindowHandle;

            driver.SwitchTo().Frame(driver.FindElement(By.Id("product-description-iframe")));
            var expression = By.ClassName("content");

            wait.Until(x => x.FindElement(expression));
            var frameElement = driver.FindElement(expression);
            currentItem.ProductDescription = frameElement.Text;

            driver.SwitchTo().Window(winHandleBefore);

            var titleExpression = By.Id("productTitle");
            wait.Until(x => x.FindElement(titleExpression));
            var titleElement = driver.FindElement(titleExpression);
            currentItem.Title = titleElement.Text;

            var oldPrice = By.CssSelector("div#price_feature_div");
            wait.Until(x => x.FindElement(oldPrice));
            var oldPriceElement = driver.FindElement(oldPrice);

            var priceElements = oldPriceElement.Text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            currentItem.OldPrice = priceElements[0];
            currentItem.Price = priceElements[1];
            currentItem.SaveRate = priceElements[2];


            var availability = By.Id("availability");
            wait.Until(x => x.FindElement(availability));
            var status = driver.FindElement(availability);
            currentItem.Availability = status.Text;


            var features = By.CssSelector("div#feature-bullets ul li");
            wait.Until(x => x.FindElements(features));
            var featuresCollection = driver.FindElements(features);

            foreach (var feat in featuresCollection)
            {
                if (feat.Text != string.Empty)
                {
                    currentItem.Features.Add(feat.Text);
                }
            }

            var imgs = By.CssSelector("span.a-button-text img");
            wait.Until(x => x.FindElements(imgs));
            var imgsCollection = driver.FindElements(imgs);

            foreach (var img in imgsCollection)
            {
                var src = img.GetAttribute("src");
                currentItem.Images.Add(src);
            }


            var productInformation = By.CssSelector("table#productDetails_detailBullets_sections1 > tbody > tr > td");
            wait.Until(x => x.FindElements(productInformation));
            var productInformationElements = driver.FindElements(productInformation);

            currentItem.ProductInfo.ProductDimensions = productInformationElements[0].Text;
            currentItem.ProductInfo.ItemWeight = productInformationElements[1].Text;
            currentItem.ProductInfo.ShippingWeight = productInformationElements[2].Text;
            currentItem.ProductInfo.Department = productInformationElements[3].Text;
            currentItem.ProductInfo.Manufacturer = productInformationElements[4].Text;
            currentItem.ProductInfo.ASIN = productInformationElements[5].Text;
            currentItem.ProductInfo.DomesticShipping = productInformationElements[6].Text;
            currentItem.ProductInfo.InternationalShiping = productInformationElements[7].Text;
            currentItem.ProductInfo.Origin = productInformationElements[8].Text;
            currentItem.ProductInfo.ShippingAdvisory = productInformationElements[9].Text;
            currentItem.ProductInfo.ItemModelNumber = productInformationElements[10].Text;
            currentItem.ProductInfo.CustomerReviews = productInformationElements[11].Text;
            currentItem.ProductInfo.BestSellerRate = productInformationElements[12].Text;

            return currentItem;
        }
    }
}
